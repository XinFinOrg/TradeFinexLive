	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url() ?>public/js/jquery-1.11.1.js"></script>
	<script src="<?php echo base_url() ?>public/js/jquery.validate.min.js"></script>
	
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url() ?>public/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>public/js/custom.js"></script>