$(document).ready(function() {
        $('#example').dataTable();
} );