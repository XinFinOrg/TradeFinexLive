<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['$econfig'] = array(
			'protocol' => 'smtp',
			'smtp_host' => 'ssl://demo.tradefinex.org',
			'smtp_port' => 465,
			'smtp_user' => 'admin@demo.tradefinex.org', 
			'smtp_pass' => 'demotrad@2017!',
			'wordwrap' => TRUE,
			'charset' => 'utf-8'
		 );