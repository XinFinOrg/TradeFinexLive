	<div id="container" style="text-align:center">
		<img src="<?=base_url();?>assets/images/page/404.png" alt="404 Not Found" />
	</div>