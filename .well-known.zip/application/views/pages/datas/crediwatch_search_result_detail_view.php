<ul>
	<li class="left_li">Company Name</li>
	<li class="left_li_point">:</li>
	<li class="left_li_text">
		<?=(isset($crediwatch_search_result['n']) ? $crediwatch_search_result['n'] : 'Not Found');?>
	</li>
</ul>
<ul>
	<li class="left_li">Type</li>
	<li class="left_li_point">:</li>
	<li class="left_li_text">
		<?=(isset($crediwatch_search_result['_type']) ? $crediwatch_search_result['_type'] : 'Not Found');?>
	</li>
</ul>
<ul>
	<li class="left_li">Category</li>
	<li class="left_li_point">:</li>
	<li class="left_li_text">
		<?=(isset($crediwatch_search_result['company_category']) ? $crediwatch_search_result['company_category'] : 'Not Found');?>
	</li>
</ul>
<ul>
	<li class="left_li">Sub Category</li>
	<li class="left_li_point">:</li>
	<li class="left_li_text">
		<?=(isset($crediwatch_search_result['company_subcategory']) ? $crediwatch_search_result['company_subcategory'] : 'Not Found');?>
	</li>
</ul>
<ul>
	<li class="left_li">Class</li>
	<li class="left_li_point">:</li>
	<li class="left_li_text">
		<?=(isset($crediwatch_search_result['class_of_company']) ? $crediwatch_search_result['class_of_company'] : 'Not Found');?>
	</li>
</ul>
<ul>
	<li class="left_li">Address</li>
	<li class="left_li_point">:</li>
	<li class="left_li_text">
		<?=(isset($crediwatch_search_result['address']) ? $crediwatch_search_result['address'] : 'Not Found');?>
	</li>
</ul>
<ul>
</ul>