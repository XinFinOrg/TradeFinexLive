<section id="watchv" class="tradefinex_about_us_video">
    <div class="container">
      <div class="col-sm-5 col-md-5 col-xs-12">
        <h2 class="">Watch Video & Learn</h2>
        <p class="text-long"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
        <p class="text-long"> It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
        <div class="col-md-4 pro_btn pull-left"> <a href="#" class="btn btn btn-primary call_to_action pull-left"> Contact Us </a> </div>
      </div>
      <div class="col-md-7 col-sm-6">
        <div class="video_part">
          <iframe src="https://www.youtube.com/embed/jLaqms1IHWE?feature=oembed" allowfullscreen="" height="600" frameborder="0" width="100%"></iframe>
        </div>
      </div>
    </div>
</section>
