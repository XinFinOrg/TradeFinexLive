<section class="flat-row flat-main-blog blog_style want_to_be">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="flat-row-title center">
					<p><img src="<?php echo base_url() ?>assets/images/icon/line.png" alt="icon"></p>
					<h2>Want To Be A TradeFinex Member?</h2>
					<p> Browse the projects under all the categories and Submit Your Proposal. </p>
				</div>
				<!-- /.flat-row-title --> 
			</div>
			<!-- /.col-md-12 --> 
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="btn-more"> <a href="<?php echo base_url() ?>registration" title="">Create An Account <span class="icon_right_margin"> <img src="<?php echo base_url() ?>assets/images/icon/arrow.png" alt="icon"></span></a> </div>
			</div>
		</div>
		<!-- /.row --> 
	 </div>
	 <!-- /.container --> 
</section>